package com.example.tictac;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    int activePlayer=0;
    int [] gameState = {2,2,2,2,2,2,2,2,2}; // 2 means unplayed
    int [][] winnigLocations = {{0,1,2},{3,4,5},{6,7,8},{0,3,6},{1,4,7},{2,5,8},{0,4,8},{2,4,6}};
    boolean gameOver = false;
    int a;
    boolean flag;

    public  void gameLogic(View view)
    {
        ImageView tappedView = (ImageView) view;
        tappedView.setTranslationY(-3000f);
        int tappedLocation = Integer.parseInt(view.getTag().toString());

        if(gameState[tappedLocation]==2 && !gameOver) {
            gameState[tappedLocation] = activePlayer;
            if (activePlayer == 0) {

                tappedView.setImageResource(R.drawable.zero);
                activePlayer = 1;
            } else {
                tappedView.setImageResource(R.drawable.crosss);
                activePlayer = 0;
            }
            tappedView.animate().translationYBy(3000f).setDuration(500);

        }

        for(int [] winnigPosotion:winnigLocations)
        {
            a++;
            if(gameState[winnigPosotion[0]]==gameState[winnigPosotion[1]] &&
                    gameState[winnigPosotion[1]]==gameState[winnigPosotion[2]]  &&
                    gameState[winnigPosotion[0]] !=2
            )
            {
                if(activePlayer==0)
                {
                    Toast.makeText(getApplicationContext(),"Cross is Win",Toast.LENGTH_SHORT).show();
                    flag=true;
                }

                else {
                    Toast.makeText(getApplicationContext(),"Zero is Win",Toast.LENGTH_SHORT).show();
                    flag=true;
                }
                gameOver=true;
            }

        }

        if(a==72 && flag==false)
        {
            Toast.makeText(getApplicationContext(),"draw",Toast.LENGTH_SHORT).show();
        }


    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}